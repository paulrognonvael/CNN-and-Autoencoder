

library(keras)
library(tidyverse)


#2. Split the dataset into 500 train /100 validation /100 test. Try to balance the two classes.

# We create a function to automatically split the data in the required format or depending on the user requirements.

random_files <- function(readpath, writepath, type, train_size, val_size, test_size, pattern = "png$|PNG$"){
      ####################################################################
      # readpath and writepath = path to folders with files to select and where to write them                                
      #                                                                            
      # train_size, val_size, test_size = percentage or number of recordings to select. If value is 
      #   between 0 and 1 percentage of files is assumed, if value greater than 1, 
      #   number of files is assumed                                               
      #                                                                            
      # pattern = file extension to select.       
      # type = normal(1) or effusion(2) types   
      ####################################################################
      
      
      ## copy original data in temp folder for separation 
      temp_path = file.path(writepath, 'temp')
      dir.create(temp_path)
      file.copy(readpath, temp_path, recursive=TRUE)
      if (type == 1){
        temp_type_path = file.path(temp_path, 'normal')
      }else if(type == 2){
        temp_type_path = file.path(temp_path, 'effusion')
      }else {print("Incorrect type")}
      
      # Get file list with full path and file names
      files <- list.files(temp_type_path, full.names = TRUE, pattern = pattern)
      file_names <- list.files(temp_type_path, pattern = pattern)
      
      # # Select the desired % or number of file by simple random sampling 
      randomize <- sample(seq(files))
      files2analyse <- files[randomize]
      names2analyse <- file_names[randomize]
      if(train_size <= 1){
        size <- floor(train_size * length(files))
      }else{
        size <- train_size
      }
      files2analyse <- files2analyse[(1:size)]
      names2analyse <- names2analyse[(1:size)]
    
      # Create folder to output
      if (type == 1){
        results_folder <- paste0(writepath, '/train/normal')
      }else if(type == 2){
        results_folder <- paste0(writepath, '/train/effusion')
      }else {print("Incorrect type")}
      dir.create(results_folder, recursive=TRUE)
    
      # copy files
      for(i in seq(files2analyse)){
        file.rename(from = files2analyse[i], to = paste0(results_folder, "/", names2analyse[i]) )
      }
    
      
      
      ##### validation
    
      files <- list.files(temp_type_path, full.names = TRUE, pattern = pattern)
      file_names <- list.files(temp_type_path, pattern = pattern)
      
      # # Select the desired % or number of file by simple random sampling
      randomize <- sample(seq(files))
      files2analyse <- files[randomize]
      names2analyse <- file_names[randomize]
      if(val_size <= 1){
        size <- floor(val_size * length(files))
      }else{
        size <- val_size
      }
      files2analyse <- files2analyse[(1:size)]
      names2analyse <- names2analyse[(1:size)]
    
      if (type == 1){
        results_folder <- paste0(writepath, '/validation/normal')
      }else if(type == 2){
        results_folder <- paste0(writepath, '/validation/effusion')
      }else {print("Incorrect type")}
      dir.create(results_folder, recursive=TRUE)
    
      # copy files
      for(i in seq(files2analyse)){
        file.rename(from = files2analyse[i], to = paste0(results_folder, "/", names2analyse[i]) )
    
    
      }

  
      
      ##### test
      
      files <- list.files(temp_type_path, full.names = TRUE, pattern = pattern)
      file_names <- list.files(temp_type_path, pattern = pattern)
      
      # # Select the desired % or number of file by simple random sampling
      randomize <- sample(seq(files))
      files2analyse <- files[randomize]
      names2analyse <- file_names[randomize]
      if(test_size <= 1){
        size <- floor(test_size * length(files))
      }else{
        size <- test_size
      }
      files2analyse <- files2analyse[(1:size)]
      names2analyse <- names2analyse[(1:size)]
      
      if (type == 1){
        results_folder <- paste0(writepath, '/test/normal')
      }else if(type == 2){
        results_folder <- paste0(writepath, '/test/effusion')
      }else {print("Incorrect type")}
      dir.create(results_folder, recursive=TRUE)
      
      
      # copy files
      for(i in seq(files2analyse)){
        file.rename(from = files2analyse[i], to = paste0(results_folder, "/", names2analyse[i]) )
      }
      
      unlink(file.path(writepath, 'temp'),recursive = TRUE)
      
}


# execute function with user arguments,
#TODO: remove temp folders after running the problem
random_files('rxtorax/normal','rxtorax', 1, 250, 50, 50, pattern = "png$|PNG$")
random_files('rxtorax/effusion','rxtorax', 2, 250, 50, 50, pattern = "png$|PNG$")

train_dir<-"rxtorax/train"
validation_dir<-"rxtorax/validation"
test_dir<-"rxtorax/test"



# 3. Implement a Convolutional Neural Network (CNN) following the instructions below:
# • The number of convolutional layers should not be greater than 6.
# • Pooling layers should be included to reduce the number of parameters.
# • At the bottom of the network, the fully connected layers will have 128 and 32 nodes
# respectively.
# • Output layer with activation ‘sigmoid’.
# • Trainable params should be at least than 60000.


# We have a model with 4 convolutional layers. At the bottom of the network, the fully connected layers have 128 and 32 nodes respectively.
# The number of Trainable parameters is 62,273.
# The output layer has ‘sigmoid’ type activation.

#Note: input_shape = c(img_width, img_height, channels)
# Note2: Padding, by adding zero-valued pixels around the borders of the image solves both problems by capturing more details and maintaining size, respectively

# initialise model
model <- keras_model_sequential() %>%
    # first convvolutional hidden layer and max pooling
  layer_conv_2d(filters = 32, kernel_size = c(3,3), padding = "valid",
                activation = "relu",input_shape = c(64, 64, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # second convvolutional hidden layer and max pooling
  layer_conv_2d(filters = 64, kernel_size = c(2, 2), padding = "valid",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # third convvolutional hidden layerand max pooling
  layer_conv_2d(filters = 64, kernel_size = c(2, 2), padding = "valid",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # fourth convvolutional hidden layer and max pooling
  layer_conv_2d(filters = 128, kernel_size = c(2, 2), padding = "valid",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # fifth convvolutional hidden layer and max pooling
  layer_conv_2d(filters = 128, kernel_size = c(2, 2), padding = "valid",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # Flatten max filtered output into feature vector
  layer_flatten() %>%
  layer_dropout(rate=0.4) %>%
    # Outputs from dense layer are projected onto output layer
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 32, activation = "relu") %>%
  layer_dense(units = 1, activation = "sigmoid")

summary(model)




  # The learning process is configured in the compilation step, 
# optimizer and loss function are specified as well as the metrics to use during training.

model %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-4),
  metrics = c("acc")
)







# 1. Normalize images.


###### About normalization of images
# The ImageDataGenerator class can be used to rescale pixel values from the range of 0-255 to the range 0-1 
# preferred for neural network models.
# 
# Scaling data to the range of 0-1 is traditionally referred to as normalization.
# 
# This can be achieved by setting the rescale argument to a ratio by which each pixel can be multiplied 
# to achieve the desired range.
# 
# In this case, the ratio is 1/255

train_datagen <- image_data_generator(rescale = 1/255)
train_generator <- flow_images_from_directory(
  train_dir,
  train_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 25,
  class_mode = "binary"
)

validation_datagen <- image_data_generator(rescale = 1/255)
validation_generator <- flow_images_from_directory(
  validation_dir,
  validation_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 25,
  class_mode = "binary"
)

test_datagen <- image_data_generator(rescale = 1/255)
test_generator <- flow_images_from_directory(
  test_dir,
  test_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 25,
  class_mode = "binary",
  classes = c("effusion","normal"),
  shuffle = FALSE
)
#  Note that the generator yields these batches indefinitely: it loops endlessly over the images in the target folder.


# sample output of one of the generators we just defined 
batch <- generator_next(train_generator)
str(batch)

# Now we have the images in the required format: 64x64 with a unique channel



# Evaluate the current model
history <- model %>% fit_generator(
  train_generator,
  steps_per_epoch = 20,
  epochs = 25,
  validation_data = validation_generator,
  validation_steps = 4
)

# validation_steps: It should typically be equal to the number of samples of your validation dataset divided by the batch size.
plot(history)

# The obtained accuracy is not very good.

model %>% save_model_hdf5("model_batch50.h5")

  
predict <- model %>% predict_generator(
  test_generator,
  steps = 4)

stat_df <- as.tibble(cbind(predict, test_generator$filenames, test_generator$classes)) %>%
  # assign prediction probability for filenames
  rename(
    predict_proba = V1,
    filename = V2,
    class = V3
  ) %>%
  mutate(predict_proba = as.double(predict_proba)) %>%
           mutate(predicted_class = ifelse(predict_proba > 0.5, 1, 0)) %>%
           mutate(predicted_class = as.integer(predicted_class)) %>% 
  mutate(label_name = ifelse(predicted_class == 0, "effusion", "normal"))
  
# 4. Tune the hyperparameter batch_size checking the values in the set {25,35,50}
#TODO: Change the batchs size and compare results.




# 5. Assess the performance of the CNN predicting the categories of test images and obtain
# the confusion matrix.
#TODO: Algo falla pq siempre predice lo mismo para todo el test...

# install.packages("BiocManager") 
# BiocManager::install("EBImage") 
library(EBImage)



# Set image size
width <- 64
height <- 64

extract_feature <- function(dir_path, width, height, labelsExist = T) {
  img_size <- width * height
  
  ## List images in path
  images_names <- list.files(dir_path)
  
  # if(labelsExist){
  #   ## Select only cats or dogs images
  #   catdog <- str_extract(images_names, "^(cat|dog)")
  #   # Set cat == 0 and dog == 1
  #   key <- c("cat" = 0, "dog" = 1)
  #   y <- key[catdog]
  # }
  
  print(paste("Start processing", length(images_names), "images"))
  ## This function will resize an image, turn it into greyscale
  feature_list <- pblapply(images_names, function(imgname) {
    ## Read image
    img <- readImage(file.path(dir_path, imgname))
    ## Resize image
    img_resized <- resize(img, w = width, h = height)
    ## Set to grayscale (normalized to max)
    grayimg <- channel(img_resized, "gray")
    ## Get the image as a matrix
    img_matrix <- grayimg@.Data
    ## Coerce to a vector (row-wise)
    img_vector <- as.vector(t(img_matrix))
    return(img_vector)
  })
  ## bind the list of vector into matrix
  feature_matrix <- do.call(rbind, feature_list)
  feature_matrix <- as.data.frame(feature_matrix)
  ## Set names
  names(feature_matrix) <- paste0("pixel", c(1:img_size))
  
  if(labelsExist){
    return(list(X = feature_matrix, y = y))
  }else{
    return(feature_matrix)
  }
}

# mixed test data
testData <- extract_feature("rxtorax/test", width, height, labelsExist = F)


test_array <- t(testData)
dim(test_array) <- c(64, 64, nrow(testData), 1)
test_array
# Reorder dimensions
test_array <- aperm(test_array, c(3,1,2,4))
test_array

# Compute probabilities and predictions on test set
predictions <-  predict_classes(model, test_array)
probabilities <- predict_proba(model, test_array)

predictions
probabilities

# Visual inspection of 32 cases
set.seed(100)
random <- sample(1:nrow(testData), 100)
preds <- predictions[random,]
probs <- as.vector(round(probabilities[random,], 2))

par(mfrow = c(5, 10), mar = rep(0, 4))
for(i in 1:length(random)){
  image(t(apply(test_array[random[i],,,], 2, rev)),
        col = gray.colors(12), axes = F)
  legend("topright", legend = ifelse(preds[i] == 0, "Normal", "Effusion"),
         text.col = ifelse(preds[i] == 0, 2, 4), bty = "n", text.font = 2)
  legend("topleft", legend = probs[i], bty = "n", col = "white")
}


# Predict the classes for the test data
classes <- model %>% predict_classes(test_array)

# Confusion matrix
library(caret)
table(mnist$test$y, classes)
confusionMatrix(as.factor(mnist$test$y), as.factor(classes))














# manual method. Channels do not match and grayscale argument is deprecated tho rendering the method useless
# rxtorax_normal_folder <- paste0('rxtorax', '/test/normal')
# test_image_1 = file.path(rxtorax_normal_folder, 'n58.png')
# 
# img<-image_load(test_image_1, grayscale=TRUE)
# img<-image_array_resize(img,64,64,data_format="channels_last")
# class(img)
# dim(img)
# img_tensor<-image_to_array(img,data_format="channels_last")
# img_tensor<-array_reshape(img_tensor,c(1,64,64,3))
# dim(img_tensor)
# img_tensor<-img_tensor/255
# plot(as.raster(img_tensor[1,,,]))
# predict(model,img_tensor)
# 
# 
# 
# img<-image_load(" ")
# img<-image_array_resize(img,32,32,data_format="channels_last")
# class(img)
# dim(img)
# img_tensor<-image_to_array(img,data_format="channels_last")
# img_tensor<-array_reshape(img_tensor,c(1,32,32,3))
# dim(img_tensor)
# img_tensor<-img_tensor/255
# plot(as.raster(img_tensor[1,,,]))
# predict(model,img_tensor)




















# 6. Re-fit the CNN including data augmentation. Was the use of augmentation an improve-
#   ment?

train_datagen <- image_data_generator(rescale = 1/255,
                                      rotation_range = 40,
                                      width_shift_range = 0.2,
                                      height_shift_range = 0.2,
                                      shear_range = 0.2,
                                      zoom_range = 0.2,
                                      horizontal_flip = TRUE)

train_generator <- flow_images_from_directory(
  train_dir,
  train_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 50,
  class_mode = "binary"
)

validation_datagen <- image_data_generator(rescale = 1/255,
                                           rotation_range = 40,
                                           width_shift_range = 0.2,
                                           height_shift_range = 0.2,
                                           shear_range = 0.2,
                                           zoom_range = 0.2,
                                           horizontal_flip = TRUE)


validation_generator <- flow_images_from_directory(
  validation_dir,
  validation_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 50,
  class_mode = "binary"
)

test_datagen <- image_data_generator(rescale = 1/255,
                                     rotation_range = 40,
                                     width_shift_range = 0.2,
                                     height_shift_range = 0.2,
                                     shear_range = 0.2,
                                     zoom_range = 0.2,
                                     horizontal_flip = TRUE)


test_generator <- flow_images_from_directory(
  test_dir,
  test_datagen,
  color_mode = "grayscale",
  target_size = c(64, 64),
  batch_size = 50,
  class_mode = "binary"
)
  

# Evaluate the current model
history <- model %>% fit_generator(
  train_generator,
  steps_per_epoch = 2,
  epochs = 25,
  validation_data = validation_generator,
  validation_steps = 2
)

# validation_steps: It should typically be equal to the number of samples of your validation dataset divided by the batch size.
plot(history)

# The obtained accuracy is not very good.

model %>% save_model_hdf5("model_batch50_aumented.h5")

# El modelo sigue dando un accuracy muy bajo.






# 8. Implement a convolutional autoencoder (CAE) network following the instructions below:
#   • The full network should have two networks: a convolutional encode and a convolu-
#   tional decode.
# • The total number of convolutional layers should not be greater than 8.
# • Pooling layers should be included to reduce the number of parameters.
# • Trainable params should be at least than 30000.



#### Convolutional Encoder 

model_enc <- keras_model_sequential() 
model_enc %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), strides = 1, padding = "same",
                activation = "relu",input_shape = c(64, 64, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
    # third hidden layer  and max pooling
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), strides = 1, padding = "same",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  # forth hidden layer  and max pooling
  layer_conv_2d(filters = 16, kernel_size = c(3, 3), strides = 1, padding = "same",
                activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2))


summary(model_enc)

#### Convolutional Decoder 

model_dec <- keras_model_sequential() 
model_dec %>%
  layer_conv_2d(filters = 16, kernel_size = c(4,4), 
                activation = "relu", padding = "same", strides = 1,
                input_shape = c(8, 8, 16))  %>%
  layer_upsampling_2d(size = c(2,2))  %>%
  layer_conv_2d(filters = 16, kernel_size = c(4,4), strides = 1,
                activation = "relu", padding = "same")  %>%
  layer_upsampling_2d(size = c(2,2))  %>%
  layer_conv_2d(filters = 8, kernel_size = c(4,4), strides = 1,
                activation = "relu", padding = "same")  %>%
  layer_upsampling_2d(size = c(2,2))  %>%
  # Important: no padding 
  layer_conv_2d(filters = 1, kernel_size = c(1,1),
                activation = "relu")

summary(model_dec)
# inputdimension  == output dimension 

#### Autoencoder 
model_auto<-keras_model_sequential()
model_auto %>%model_enc%>%model_dec

summary(model_auto)

##########################################################

model_auto %>% compile(
  loss = "binary_crossentropy",
  optimizer = optimizer_rmsprop(lr = 1e-4),
  metrics = c("acc")
)

# model_auto %>% compile(
#   loss = "mean_squared_error",
#   #optimizer = optimizer_rmsprop(),
#   optimizer = "adam",
#   metrics = c("mean_squared_error")
# )

######################################## Training 
# Evaluate the current model
#TODO: esto no va
history <- model_auto %>% fit_generator(
  train_generator,
  steps_per_epoch = 2,
  epochs = 25,
  validation_data = validation_generator,
  validation_steps = 2
)

history <- model %>% fit(
  x= x_train_cifra, y = x_train_cifra,   # Autoencoder
  epochs = 5, batch_size = 128, 
  suffle = TRUE,
  validation_split = 0.2
  #  validation_data = list(x_test_cifra,x_test_cifra)
)


# validation_steps: It should typically be equal to the number of samples of your validation dataset divided by the batch size.
plot(history)








